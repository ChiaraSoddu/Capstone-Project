package com.chiarasoddu.gymapp.models;

public enum SubType {

	MENSILE,
	SEMESTRALE,
	ANNUALE
	
}
