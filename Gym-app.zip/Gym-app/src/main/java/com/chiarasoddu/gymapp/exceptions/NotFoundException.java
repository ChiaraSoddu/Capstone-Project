package com.chiarasoddu.gymapp.exceptions;

public class NotFoundException extends RuntimeException {

	public NotFoundException(String m){
		super(m);
	}
	
}
