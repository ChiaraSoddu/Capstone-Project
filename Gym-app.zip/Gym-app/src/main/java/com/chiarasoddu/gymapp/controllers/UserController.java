package com.chiarasoddu.gymapp.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chiarasoddu.gymapp.models.RoleType;
import com.chiarasoddu.gymapp.models.User;
import com.chiarasoddu.gymapp.services.RoleService;
import com.chiarasoddu.gymapp.services.UserService;


@RestController
@RequestMapping("/users") 
@CrossOrigin("http://localhost:3000/")
public class UserController {

    private final Logger logger = LoggerFactory.getLogger(UserController.class);
    
    @Autowired
    PasswordEncoder encoder;

    @Autowired
    UserService userService;
    
    @Autowired
    RoleService roleService;
    
    
//---------------------------- Get ---------------------------------
    
    @GetMapping("/")
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    public ResponseEntity<Page<User>> getUserList(Pageable p) {
    	
    	Page<User> res = userService.getAll(p);
        
    	 if (res.isEmpty()){
             return new ResponseEntity<>(HttpStatus.NO_CONTENT);
         } else{
             return new ResponseEntity<>(res, HttpStatus.OK);
         }
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    public User getUserById(@PathVariable("id") int id) {
        return userService.getById(id);
    }
    
    @GetMapping("/get/{username}")
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    public User getUserByUsername(@PathVariable("username") String username) {
        return userService.getByUsername(username);
    }
    
//---------------------------- Post --------------------------------

    @PostMapping("/")
//    @PreAuthorize("hasRole('ADMIN')")
    public User saveUser( 
            @RequestParam(value="name",required=false) String name,
            @RequestParam(value="lastname",required=false) String lastname,
            @RequestParam(value="username",required=true) String username,
            @RequestParam(value="email",required=true) String email,
            @RequestParam(value="password",required=true) String password
    ) {
        User user = User.builder()
        		.name(name)
        		.lastname(lastname)
        		.username(username)
        		.email(email)
        		.password(encoder.encode(password))
        		.active(true)
        		.build();

        logger.info("Save User in UserController");
        return userService.save(user);
    }

  
            
    
    
    
//---------------------------- Put ---------------------------------
    
	@PutMapping("/{id}/add-role/{roleType}")
//	@PreAuthorize("hasRole('ADMIN')")
	public void addRole(@PathVariable("id") int id, @PathVariable("roleType") RoleType roleType) {
		User u = userService.getById(id);
		u.addRole(roleService.getByRole(roleType));
		
		
		userService.save(u);
		 logger.info("Role added");
	}

    @PutMapping("{id}")
    public User updateUser(
            @PathVariable("id") int id,
            @RequestParam(value="name",required=false) String name,
            @RequestParam(value="lastname",required=false) String lastname,
            @RequestParam(value="username",required=false) String username,
            @RequestParam(value="email",required=false) String email,
            @RequestParam(value="password",required=false) String password
            ) {

        User user = userService.getById(id);

        if(name != null) user.setName(name);
        if(lastname != null) user.setLastname(lastname);
        if(username != null) user.setUsername(username);
        if(email != null) user.setEmail(email);
        if(password != null) user.setPassword(password);

        userService.save(user);
        return user;
    }

// -------------------------- Delete -------------------------------

    @DeleteMapping("{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public String deleteUserById(@PathVariable("id") int id) {
        userService.deleteById(id);
        return "User deleted successfully";
    }
    
    
 // ---------------------------- Tests --------------------------   
    
//    @GetMapping("users-paginate-byname/{name}")
//    public Page<User> getByNameAndPaginate(@PathVariable("name")String name, Pageable p){
//        Page<User> res =  userService.getByNameAndPaginate(name, p);
//        return res;
//
//    }
//    
//    @GetMapping("test/test1")
//    public String test1(){
//        return "java";
//    }
//    
//    @GetMapping("test/test2")
//    public String test2(){
//        return "java";
//    }
    
}
