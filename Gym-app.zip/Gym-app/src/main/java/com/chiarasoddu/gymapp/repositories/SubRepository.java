package com.chiarasoddu.gymapp.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.chiarasoddu.gymapp.models.Sub;

@Repository
public interface SubRepository extends JpaRepository<Sub, Integer>{
	
	@Query("SELECT s FROM Sub s WHERE s.owner.username = :username")
	Optional<Sub> findSubByUsername(@Param("username")String username);

	
}
