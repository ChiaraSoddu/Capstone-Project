package com.chiarasoddu.gymapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chiarasoddu.gymapp.models.Sub;
import com.chiarasoddu.gymapp.repositories.SubRepository;


@Service
public class SubService {

	@Autowired
	 SubRepository sr;
	
	public List<Sub> getAll(){
		return sr.findAll();
	}
	
	public Optional<Sub> getById(int id){
		return sr.findById(id);
	}
	
	public void deleteById(int id) {
		 sr.deleteById(id);
	}
	
	public Sub saveSub(Sub sub) {
		sr.save(sub);
		return(sub);
	}
	
	public Optional<Sub> getSubByUsername(String username){
		return sr.findSubByUsername(username);
	}
}
