package com.chiarasoddu.gymapp.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.chiarasoddu.gymapp.models.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	@Query("SELECT u FROM User u WHERE u.username = :username")
	Optional<User> findByUsername(@Param("username")String username);
    
    Optional<User> findById(int id);
    
    @Query("SELECT u FROM User u WHERE u.subscription.id = :id")
    Optional<User> findBySubscription(@Param("id") int id);
}
