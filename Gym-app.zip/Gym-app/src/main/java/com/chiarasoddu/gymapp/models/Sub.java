package com.chiarasoddu.gymapp.models;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.*;

	@Entity
	@Table(name = "sub")
	@Getter
	@Setter
	@ToString
	@NoArgsConstructor
	@AllArgsConstructor
	@Builder
public class Sub {
	
	    
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;
	    private SubType subtype;
	    private LocalDate start;
	    private LocalDate exp;
	    
	    @JsonManagedReference
	    @OneToOne
	    private User owner;
	    
//	    @OneToMany
//	    @JoinColumn(name= "usersub_id")
//	    private List<User> userlist = new ArrayList<>();
//	    
	   
	   
	    
}
