package com.chiarasoddu.gymapp.controllers;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.chiarasoddu.gymapp.models.Sub;
import com.chiarasoddu.gymapp.models.SubType;
import com.chiarasoddu.gymapp.models.User;
import com.chiarasoddu.gymapp.services.SubService;
import com.chiarasoddu.gymapp.services.UserService;

@RestController
@RequestMapping("/subscription")
public class SubController {

	@Autowired
	SubService ss;
	
	@Autowired
	UserService us;
	
	@GetMapping("/{id}")
	public Optional<Sub> getById(@PathVariable("id") int id){
		return ss.getById(id);
	}
	
	@GetMapping("/")
	public List<Sub> getAll(){
		return ss.getAll();
	}
	
	@PostMapping("/")
	public Sub saveSub(
			@RequestParam("owner_id") int id,			
			@RequestParam("type") SubType subtype
			) {
		LocalDate end;
		LocalDate start = LocalDate.now();
		
		
		switch(subtype) {
			case MENSILE: 
				end = start.plusMonths(1);
				break;
			case SEMESTRALE: 
				end = start.plusMonths(6);
				break;
			case ANNUALE: 
				end = start.plusYears(1);
				break;
			default: 
				end = start;
				break;
		}
		
		User owner = us.getById(id);
		
		if(owner
				.getSubscription()
				.getExp()
				.isAfter(LocalDate.now())
				) {
			return null;
		}
		
		Sub sub = Sub.builder()
			.start(start)
			.exp(end)
			.owner(owner)
			.subtype(subtype)
			.build();
		
		ss.saveSub(sub);
		
		owner.setSubscription(sub);
		
		us.save(owner);
		
		return sub;
	}
	
	
	
	
	@DeleteMapping("/{id}")
	public String deleteById(@PathVariable("id") int id) {
		
		Optional<User> u = us.getBySubscription(id);
		if(u.isPresent()) {
			
			User user = u.get();
			user.setSubscription(null);
			us.save(user);
			
		}
		ss.deleteById(id);
		return "Hai annullato il tuo abbonamento";
	}
}
