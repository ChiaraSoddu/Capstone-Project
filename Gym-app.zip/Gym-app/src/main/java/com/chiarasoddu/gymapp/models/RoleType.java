package com.chiarasoddu.gymapp.models;

public enum RoleType {
	
    ROLE_USER,
    ROLE_ADMIN;
	
}
